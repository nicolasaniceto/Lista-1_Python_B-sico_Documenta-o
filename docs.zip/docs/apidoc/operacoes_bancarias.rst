operacoes\_bancarias module
===========================

.. automodule:: operacoes_bancarias
   :members:
   :show-inheritance:
   :undoc-members:
